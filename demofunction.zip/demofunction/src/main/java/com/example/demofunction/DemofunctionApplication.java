package com.example.demofunction;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemofunctionApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemofunctionApplication.class, args);
	}

}
